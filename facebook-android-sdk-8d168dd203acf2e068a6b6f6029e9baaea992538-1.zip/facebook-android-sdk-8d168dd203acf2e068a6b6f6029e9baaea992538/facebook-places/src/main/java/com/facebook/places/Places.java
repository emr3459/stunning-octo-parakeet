// Copyright 2004-present Facebook. All Rights Reserved.

package com.facebook.places;

public class Places { }
